<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PathController extends Controller
{
    public function add_user()
    {
        return view('add_user');
    }

}
